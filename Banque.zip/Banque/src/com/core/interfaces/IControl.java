package com.core.interfaces;

public interface IControl {

	public boolean isValid();
	public boolean isNew();
}
