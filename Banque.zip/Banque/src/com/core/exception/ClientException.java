package com.core.exception;

public class ClientException extends Exception{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public ClientException()
	{
		System.out.println("Impossible de creer ce client");
	}

}
